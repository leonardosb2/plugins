assets folder is for screenshots etc for documentation and not part of the release distribution
