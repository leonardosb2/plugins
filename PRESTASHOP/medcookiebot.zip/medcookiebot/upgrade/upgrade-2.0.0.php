<?php
/**
 * 2008-2016 Mediacom87
 *
 * NOTICE OF LICENSE
 *
 * Read in the module
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    Mediacom87 <support@mediacom87.net>
 * @copyright 2008-2016 Mediacom87
 * @license   define in the module
 *
 */

if (!defined('_TB_VERSION_')
    && !defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_2_0_0($module)
{
    if (version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
        if (!$module->registerHook('Header')
            || !$module->unregisterHook('actionFrontControllerSetMedia')) {
            return false;
        }
    }
    return true;
}
