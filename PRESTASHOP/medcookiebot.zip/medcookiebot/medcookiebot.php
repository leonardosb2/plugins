<?php
/**
 * 2008-today Mediacom87
 *
 * NOTICE OF LICENSE
 *
 * Read in the module
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    Mediacom87 <support@mediacom87.net>
 * @copyright 2008-today Mediacom87
 * @license   define in the module
 */

if (!defined('_TB_VERSION_')
    && !defined('_PS_VERSION_')) {
    exit;
}

include_once dirname(__FILE__) . '/class/mediacom87.php';

class MedCookiebot extends Module
{
    public $smarty;
    public $context;
    public $controller;
    private $errors = array();
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'medcookiebot';
        $this->tab = 'front_office_features';
        $this->version = '3.0.0';
        $this->author = 'Mediacom87';
        $this->need_instance = 0;
        $this->module_key = 'ae2710fa682bcc32d452ed5d84b1b86d'; // ae2710fa682bcc32d452ed5d84b1b86d
        $this->addons_id = '39825'; // 39825
        $this->author_address = '0x58fc3c5faebac44d590fa20ca7757cc802ad2708';
        $this->ps_versions_compliancy = array('min' => '1.5.0.0', 'max' => '1.7.99.99');

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = 'Cookiebot';
        $this->description = $this->l('This module allows you to easily integrate the script offered by the Cookiebot solution that helps you make your cookie usage and online tracking compliant with GDPR and EPR.');

        $this->conf = unserialize(Configuration::get($this->name));
        $this->mediacom87 = new MedCookiebotClass($this);

        $this->tpl_path = _PS_MODULE_DIR_.$this->name;
    }

    public function install()
    {
        if (!parent::install()
            || !$this->defaultConf()
            || !$this->registerHook('Header')) {
            return false;
        }

        if (version_compare(_PS_VERSION_, '1.6.0.0', '>=')
            && version_compare(_PS_VERSION_, '1.6.1.12', '<')) {
            // Saving the initial file
            if (!$this->mediacom87->moveFile(
                _PS_CLASS_DIR_.'Media.php',
                $this->tpl_path.'/libraries/replace/Media-old.php'
            )) {
                return false;
            }
            // Repalace the initial file
            if (!$this->mediacom87->moveFile(
                $this->tpl_path.'/libraries/replace/Media.php',
                _PS_CLASS_DIR_.'Media.php'
            )) {
                return false;
            }
        }

        return true;
    }

    public function uninstall()
    {
        if (!parent::uninstall()
            || !Configuration::deleteByName($this->name)) {
            return false;
        }
        // Restoring the initial file
        if (!$this->mediacom87->moveFile(
            $this->tpl_path.'/libraries/replace/Media-old.php',
            _PS_CLASS_DIR_.'Media.php',
            true
        )) {
            return false;
        }

        return true;
    }

    public function getContent($tab = 'AdminModules')
    {
        $output = '';

        $form_url = AdminController::$currentIndex
            .'&amp;configure='.$this->name
            .'&amp;token='.Tools::getAdminToken(
                $tab
                .(int)Tab::getIdFromClassName($tab)
                .(int)$this->context->cookie->id_employee
            );

        if (Tools::isSubmit('saveconf')) {
            $this->postProcess();

            if (count($this->errors)) {
                $output .= $this->displayError(implode('<br />', $this->errors));
            } else {
                Tools::redirectAdmin(html_entity_decode($form_url).'&conf=6');
            }
        }

        if (isset($this->addons_id) && $this->addons_id) {
            $json_rates = $this->mediacom87->medJsonModuleRate($this->addons_id, $this->module_key);
        } else {
            $json_rates = null;
        }

        if (isset($this->module_key) && $this->module_key) {
            $json_modules = $this->mediacom87->medJsonModuleFile();
        } else {
            $json_modules = null;
        }
        $this->context->smarty->assign(
            array(
                'form_url' => $form_url,
                'addons_id' => $this->addons_id,
                'tpl_path' => $this->tpl_path,
                'img_path' => $this->_path.'views/img/',
                'base_link' => $this->context->shop->getBaseURI(),
                'languages' => Language::getLanguages(false),
                'description' => $this->description,
                'author' => $this->author,
                'name' => $this->name,
                'version' => $this->version,
                'ps_version' => defined('_PS_VERSION_') ? _PS_VERSION_ : null,
                'tb_version' => defined('_TB_VERSION_') ? _TB_VERSION_ : null,
                'php_version' => phpversion(),
                'iso_code' => $this->mediacom87->isoCode(),
                'iso_domain' => $this->mediacom87->isoCode(true),
                'id_active_lang' => $this->context->language->id,
                'json_modules' => $json_modules,
                'json_rates' => $json_rates,
                'config' => $this->conf,
                'declaration' => $this->context->link->getModuleLink($this->name, 'declaration', array(), null, $this->context->language->id, $this->context->shop->id),
                'adminPerformancesLink' => $this->context->link->getAdminLink('AdminPerformance', true),
            )
        );
        $this->context->controller->addJS($this->_path.'libraries/js/riotcompiler.min.js');
        $this->context->controller->addJS($this->_path.'libraries/js/pageloader.js');
        $this->context->controller->addJS($this->_path.'views/js/admin.js');

        if (version_compare(_PS_VERSION_, '1.6.0.0', '<')) {
            $this->context->controller->addJS('https://use.fontawesome.com/8ebcaf88e9.js');
        }

        $this->context->controller->addCSS($this->_path.'views/css/back.css');

        $output .= $this->display(__FILE__, 'views/templates/admin/admin.tpl');
        $output .= $this->display(__FILE__, 'libraries/prestui/ps-tags.tpl');

        return $output;
    }

    public function defaultConf()
    {
        $conf = array();

        $conf['DisplayBanner'] = true;
        $conf['DomainGroupID'] = '';
        $conf['ForceLang'] = true;
        $conf['declarationInFull'] = false;

        foreach (Language::getLanguages() as $lang) {
            $conf['declarationTitle'][(int)$lang['id_lang']] = '';
        }

        if (!Configuration::updateValue($this->name, serialize($conf))) {
            return false;
        }

        return true;
    }

    public function postProcess()
    {
        $this->conf['DisplayBanner'] = (bool)Tools::getValue('DisplayBanner');
        $this->conf['DomainGroupID'] = trim((string)Tools::getValue('DomainGroupID'));
        $this->conf['ForceLang'] = (bool)Tools::getValue('ForceLang');
        $this->conf['declarationInFull'] = (bool)Tools::getValue('declarationInFull');

        foreach (Language::getLanguages() as $lang) {
            $this->conf['declarationTitle'][(int)$lang['id_lang']] = Tools::getValue('declarationTitle_'.(int)$lang['id_lang']);
        }

        if (!Configuration::updateValue($this->name, serialize($this->conf))) {
            $this->errors[] = $this->l('Error during settings update');
        }
    }

    public function hookHeader()
    {
        if ($this->active
            && isset($this->conf['DisplayBanner'])
            && $this->conf['DisplayBanner']
            && isset($this->conf['DomainGroupID'])
            && !Tools::isEmpty($this->conf['DomainGroupID'])) {
            $this->context->smarty->assign(
                array(
                   'conf' => $this->conf,
                   'medIsoLang' => $this->context->language->iso_code
                )
            );
            return $this->display(__FILE__, 'views/templates/hook/js.tpl');
        }
    }

    public function hookDisplayHeader()
    {
        return $this->hookHeader();
    }
}
