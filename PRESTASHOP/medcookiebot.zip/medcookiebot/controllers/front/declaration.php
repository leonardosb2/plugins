<?php
/**
 * 2008-today Mediacom87
 *
 * NOTICE OF LICENSE
 *
 * Read in the module
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    Mediacom87 <support@mediacom87.net>
 * @copyright 2008-today Mediacom87
 * @license   define in the module
 */

if (!defined('_TB_VERSION_')
    && !defined('_PS_VERSION_')) {
    exit;
}

class MedCookieBotDeclarationModuleFrontController extends ModuleFrontController
{
    public $ssl = true;

    public function initContent()
    {
        parent::initContent();
        if ($this->module->active
            && isset($this->module->conf['DomainGroupID'])
            && !Tools::isEmpty($this->module->conf['DomainGroupID'])
            && isset($this->module->conf['declarationInFull'])
            && $this->module->conf['declarationInFull']) {
            if (isset($this->module->conf['declarationTitle'][(int)$this->context->language->id])
                && !Tools::isEmpty($this->module->conf['declarationTitle'][(int)$this->context->language->id])) {
                $declarationTitle = $this->module->conf['declarationTitle'][(int)$this->context->language->id];
            } else {
                $declarationTitle = $this->module->l('Cookies declaration page', 'declaration');
            }
            $this->context->smarty->assign(
                array(
                    'DomainGroupID' => $this->module->conf['DomainGroupID'],
                    'declarationTitle' => $declarationTitle,
                )
            );
            if (version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
                $this->setTemplate('module:'.$this->module->name.'/views/templates/front/declaration17.tpl');
            } else {
                $this->setTemplate('declaration.tpl');
            }
        } else {
            die('This page doesn\'t exist!');
        }
    }

    public function getBreadcrumbLinks()
    {
        $breadcrumb = parent::getBreadcrumbLinks();

        if (isset($this->module->conf['declarationTitle'][(int)$this->context->language->id])
            && !Tools::isEmpty($this->module->conf['declarationTitle'][(int)$this->context->language->id])) {
            $declarationTitle = $this->module->conf['declarationTitle'][(int)$this->context->language->id];
        } else {
            $declarationTitle = $this->module->l('Cookies declaration page', 'declaration');
        }

        $breadcrumb['links'][] = array(
            'title' => $declarationTitle,
            'url' => $this->context->link->getModuleLink($this->module->name, 'declaration'),
        );

        return $breadcrumb;
    }
}
