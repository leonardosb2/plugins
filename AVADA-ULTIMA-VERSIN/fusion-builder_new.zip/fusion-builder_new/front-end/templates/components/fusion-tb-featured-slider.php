<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_tb_featured_slider-shortcode">
	<div {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{ FusionPageBuilderApp.renderContent( output, cid, false ) }}}
	</div>
</script>
