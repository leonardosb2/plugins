<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_highlight-shortcode">
	<span {{{ _.fusionGetAttributes( attr ) }}}>{{{ output }}}</span>
</script>
