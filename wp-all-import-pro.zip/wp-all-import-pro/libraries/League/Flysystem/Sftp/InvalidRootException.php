<?php

namespace League\Flysystem\Sftp;

class InvalidRootException extends \RuntimeException implements SftpAdapterException
{
}
